<?php
$title = "Dealers";
include('layouts/header.php');
?>

<section class="pageBanner">
    <img src="./assets/images/banners/spare-parts.jpg" class="img-fluid" alt="">
    <div class="container-mid">
        <div class="pageBanner-content pageBanner-filter">
            <h1>Find Truck Dealer Showrooms Near You</h1>
            <p>The most comprehensive truck comparison tool in India.</p>
            <form class="pageBanner-filterForm">
                <div class="row no-margin">
                    <div class="col-6 col-sm-4 no-padding">
                        <div class="form-group mb-0">
                            <select class="form-control" id="exampleFormControlSelect2">
                                <option>Select Brand</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-6 col-sm-4 no-padding">
                        <div class="form-group mb-0">
                            <select class="form-control" id="exampleFormControlSelect2">
                                <option>Select Brand</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 col-sm-4 no-padding">
                        <button type="submit" class="w-100 fillBtn">Search</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>

<section class="pageInfo-breadcrumbs">
    <div class="container-mid">
        <ul class="mb-0">
            <li><a href="#">Home</a></li>
            <li><span>Truck Dealers</span></li>
        </ul>
    </div>
</section>

<section class="sectionpadding25">
    <div class="container-mid">
        <div class="sectionHeading mb-0">
            <h2>Truck Dealer Showrooms in India</h2>
            <p class="mb-0">Ashok Leyland was established as Ashok Motors in the year 1948 and later rechristened to
                Ashok Leyland in 1955 after collaborating with British Leyland Motors under Hinduja Group. The automaker
                offers several products in its range of commercial vehicles from trucks and tractors to tippers and
                mini-trucks. Amongst the most popular models Dost+, Dost Strong, DOST CNG, Partner 6 Tyre, 1920 have
                taken the brand image to a whole new level. The price of Ashok Leyland truck starts from ₹ 17.53 Lakh
                for the most economic model in its lineup, the Ecomet 1015 HE. The most expensive Truck in Ashok Leyland
                lineup is the 4825, priced at ₹ 45.32 Lakh also includes Truck, Pickup, Mini Truck, Tipper, Tractor and
                Transit Mixer. The company already started migrating to BS-Vi standards in 2020 and has successfully
                implemented the technology across its range of vehicles.</p>
        </div>
    </div>
</section>

<section class="sectionpadding25 pt-0">
    <div class="container-mid">
        <div class="sectionHeading">
            <h2>911 Ashok Leyland Trucks Dealers</h2>
        </div>
        <div class="row">

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 col-lg-3">
                <div class="dealerBlock-inner sectionShadow m-b-16">
                    <h4>RDB Tractors Pvt. Ltd.</h4>
                    <div class="dealer-inner-content">
                        <p class="dealerBlock-location"><img src="assets/images/icons/location.svg" /> Sp Ring Road, Nr.
                            Canal, Sanathal, Opp. Essar Petrol Pump, Ahmedabad, Gujarat 382210</p>
                        <p class="dealerBlock-email oneline"><img src="assets/images/icons/mail.svg" /> salesmanager@conceptjeep.in
                        </p>
                        <p class="dealerBlock-contact oneline"><img src="assets/images/icons/phone.svg" /> 7575007069</p>
                        <a href="#" class="linkclr d-block text-right boldfont">Read More</a>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="text-center mt-3">
            <a href="#" class="fillBtn">Load More Trucks</a>
        </div>
    </div>
</section>

<section class="sectionpadding25 greybg">
    <div class="container-mid">
        <div class="sectionHeading">
            <h2>Search Truck Dealers By Brands</h2>
        </div>
        <div class="brandsBlock text-center tj-row">
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/ashok-leyland.png" class="img-fluid" alt="" />
                        <p>Ashok Leyland</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/bharat-benz.png" class="img-fluid" alt="" />
                        <p>Bharat Benz</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/eicher.png" class="img-fluid" alt="" />
                        <p>Eicher</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/mahindra.png" class="img-fluid" alt="" />
                        <p>Mahindra</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/piaggio.png" class="img-fluid" alt="" />
                        <p>Piaggio</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/tata.png" class="img-fluid" alt="" />
                        <p>TATA</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/ashok-leyland.png" class="img-fluid" alt="" />
                        <p>Ashok Leyland</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/bharat-benz.png" class="img-fluid" alt="" />
                        <p>Bharat Benz</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/eicher.png" class="img-fluid" alt="" />
                        <p>Eicher</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/mahindra.png" class="img-fluid" alt="" />
                        <p>Mahindra</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/piaggio.png" class="img-fluid" alt="" />
                        <p>Piaggio</p>
                    </div>
                </a>
            </div>
            <div class="brandsBlock-main tj-col">
                <a href="#">
                    <div class="brandsBlock-inner m-b-16 sectionShadow">
                        <img src="assets/images/brands/tata.png" class="img-fluid" alt="" />
                        <p>TATA</p>
                    </div>
                </a>
            </div>
        </div>
        <div class="viewall mt-1">
            <a href="#" class="boldfont">View All Brands <img src="assets/images/icons/linkarrow.svg" alt="" /></a>
        </div>
    </div>
</section>

<section class="filterBlock sectionpadding25">
    <div class="container-mid">
        <div class="sectionHeading">
            <h2>Truck Dealers in popular cities</h2>
        </div>
        <div class="row">
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Nashik</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Pune</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Ahmadnagar</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Chittoor</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Belgaum</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Satara</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Nashik</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Pune</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Ahmadnagar</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Chittoor</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Belgaum</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Satara</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Nashik</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Pune</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Ahmadnagar</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Chittoor</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Belgaum</a>
            </div>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <a class="filterBlock-chips sectionShadow boldfont text-center" href="#">Satara</a>
            </div>
        </div>
    </div>
</section>

<section class="bottomDetailBlock greybg ckeditorBlock sectionpadding25">
    <div class="container-mid">
        <div class="sectionHeading">
            <h2>Popular Truck Searches</h2>
        </div>
        <h3>What is Lorem Ipsum?</h3>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
            industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
            scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap
            into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the
            release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing
            software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
            industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and
            scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap
            into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the
            release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing
            software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>
</section>

<?php include('layouts/footer.php'); ?>