<?php
$title = "Page Not Found";
include('layouts/header.php');
?>

<section class="pt-5 pb-5 text-center">
    <div class="container-mid">
        <div class="mb-3">
            <img class="img-fluid" src="./assets/images/no-result-found.jpg" alt="">
        </div>
        <a href="#" class="fillBtn">Back to Home Page</a>
    </div>
</section>

<?php include('layouts/footer.php'); ?>